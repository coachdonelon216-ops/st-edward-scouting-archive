$ErrorActionPreference = 'Stop'
$repo = 'https://github.com/coachdonelon216-ops/st-edward-scouting-archive.git'
$source = Join-Path $PSScriptRoot 'public'
if (-not (Test-Path $source)) { throw 'Missing public folder. Extract the ZIP first.' }
$git = Get-Command git -ErrorAction SilentlyContinue
if (-not $git) { throw 'Git was not found. Install Git for Windows or GitHub Desktop first, then retry.' }
$dest = Join-Path $env:TEMP 'st-edward-scouting-archive-upload'
if (Test-Path $dest) { Remove-Item -Recurse -Force $dest }
& git clone $repo $dest
if ($LASTEXITCODE -ne 0) { throw 'Git clone failed. Sign in to GitHub.' }
New-Item -ItemType Directory -Path (Join-Path $dest 'public') -Force | Out-Null
Copy-Item -Path (Join-Path $source '*') -Destination (Join-Path $dest 'public') -Recurse -Force
Push-Location $dest
try {
  & git add public
  & git -c user.name='St. Edward Archive' -c user.email='archive@users.noreply.github.com' commit -m 'Publish scouting reports and schedule'
  & git push origin main
  if ($LASTEXITCODE -ne 0) { throw 'Push failed. Check GitHub sign-in and permissions.' }
  Write-Host 'SUCCESS: Scouting reports pushed to GitHub. Render will deploy automatically.' -ForegroundColor Green
} finally { Pop-Location }
Read-Host 'Press Enter to close'
